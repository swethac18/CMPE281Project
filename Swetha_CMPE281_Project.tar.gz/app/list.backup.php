<?php
	require 'start.php';
	
//	$s3Client = (new Aws\Sdk)->createMultiRegionS3(['version' => 'latest']);

//	$allObjects = $s3Client->listObjects(['Bucket' => $config['s3']['bucket']);
	$objects = $s3->getIterator('ListObjects', 
	[
		'Bucket' => $config['s3']['bucket']
	]);


?>

<html>
	<head>
		<title> Listing all S3 files </title>
	</head>
<body>
	<h1> List of S3 files uploaded by various users </h1>
	<h2> Main AZ US West(oregon) </h2>

	<h3>working copy backup dont delete</h3>
	<br>
	<?php foreach($objects as $object): 
	?>
	
		 <?php echo "FileName:";
			 echo $object['Key']; ?> -- 
		 <?php echo "Last updated on:";echo $object['LastModified']; ?> --
		 <?php echo "Created by:"; echo $object['Owner']['DisplayName']; ?> 
		<font color=red>click here for
		<a href="<?php echo $s3->getObjectUrl($config['s3']['bucket'],$object['Key'])?>" download = "<?php $object['Key']?>"> Download link</a>
				</font>

	<br>
	<?php endforeach; ?>

	

</body>
</html>	
