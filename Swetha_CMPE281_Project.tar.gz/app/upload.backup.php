<?php
	use Aws\S3\Exception\S3Exception;
	require 'start.php';
	require 'dbinfo.php';
	if (isset($_FILES['file'])) {
		$file = $_FILES['file'];
		$name = $file['name'];
		$tmp_name = $file['tmp_name'];
		$extension = explode('.', $name);
		$extension = strtolower(end($extension));
		$tmp_file_name = 'files/'.$user_name.$name;
		$result  = move_uploaded_file($tmp_name, $tmp_file_name);

		if ($result == TRUE) {
		   echo "<b>Uploaded to intermediate server<br>";
		   echo "trying to upload to S3<br>";
		   try {
	           $s3->putObject(
                        [
                          'Bucket' => $config['s3']['bucket'],
                          'Key' => $name,
                          'Body' => fopen($tmp_file_name, 'rb'),
			   'ACL' => 'public-read'
                        ]
                   );
		   echo "Successfully completed put object operation. Upload to S3 complete<br>";
		   echo "file name:".$name;
		   echo "</b><br><br> <br>";
                   unlink($tmp_file_path);
		   if (isset($_POST['description'])) {
			$description = $_POST['description'];	
			$date = date("D M d, Y G:i");

			$select_query = "SELECT * FROM s3object";
			$result = mysqli_query($connection, $select_query);
			$flag = 1;
			while ($query_data = mysqli_fetch_row($result)) {
				if ($query_data[0] == $name) {
					echo "<br><b>Looks like this file had been uploaded already and this an update</b><br>";
					echo "created time or original description will not be changed<br>";
					$flag = 0;
					break;
				}
			}
			if ($flag == 1) {
				$insert_query = "INSERT INTO s3object values('".$name."','".$description."','".$date."')";
				$result= mysqli_query($connection, $insert_query);
			}
				
		   }
		} catch(S3Exception $e) {
			echo "There was an error uploading the file to S3<br>";
			echo $e;
		}
		} else {
			echo "not successful";
			echo "<br> Check one of the following reasons:<br>";
			echo "It could be because of network issue<br>";
			echo "Reduce file size, i had imposed a file size of 10 MB<br>";
			echo "memory limit exceeded as i am using a smaller instance";
		}

	}
	mysqli_close($connection);
?>
<html>
	<head>
	</head>
	<body>
	<br>
	<h3> Use this page to upload file </h3>

		<table>
	<form action="" method="post" enctype="multipart/form-data">
		<tr>
		<td> Description: <input type="text" size=100 value ="default description" name="description"> </td>
		</tr>

		<tr> <input type="file" name="file"> </tr>
		<tr> <input type="submit" value="upload"> </tr>
	</form>

		</table>
        <br> To list all files uploaded to S3:<a href="list.php"> Click Here </a>
	</body>

</html>

